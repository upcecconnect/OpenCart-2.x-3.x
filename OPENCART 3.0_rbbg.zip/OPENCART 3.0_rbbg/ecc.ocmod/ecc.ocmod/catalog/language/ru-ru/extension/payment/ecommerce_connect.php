<?php
$_['text_title'] = 'Оплата Visa, MasterCart';
$_['text_order_number'] = 'Номер заказа';
