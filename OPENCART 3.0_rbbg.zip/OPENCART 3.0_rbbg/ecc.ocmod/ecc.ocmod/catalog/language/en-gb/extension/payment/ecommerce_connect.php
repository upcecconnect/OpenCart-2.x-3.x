<?php
$_['text_title'] = 'ECommerceConnect';
$_['text_order_number'] = 'Order # ';
